# Introduction
Currently working as an accountant and tax specialist. Have a background in both accounting and finace.
Working towards becoming a financial analyst.
Chose Fintech because it creates a path for my career goal of becoming a financial analyst. Also it gives me more knowledge when it comes to tech.
